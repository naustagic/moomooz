#!/etc/php8z/php/ -f
<?php
require_once("DiscordClient.php");
new \RPurinton\Moomoo\DiscordClient;
